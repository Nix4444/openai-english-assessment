import React from 'react';
//import Navbar from './components/Navbar';
//import Assessment from './components/Assessment';
import SpeakingTest from './components/SpeakingTest';
//import { BrowserRouter,Route,Routes } from "react-router-dom";
import FaceDetectionComponent from './components/proctor';


function App() {
  return (
    <>
    
    <SpeakingTest/>
    <FaceDetectionComponent/>
    </>
  );
}

export default App;