import React, { useState, useRef } from 'react';
import './SpeakingTest.css'; // Ensure this path is correct
import logo from './logo.png'; // Ensure this path is correct
import loadingAnimation from './loading.gif'; // Ensure this path is correct

const SpeakingTest = () => {
  const [difficulty, setDifficulty] = useState('Novice');
  const [isLoading, setIsLoading] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [question, setQuestion] = useState('');
  const [transcription, setTranscription] = useState('');
  const [analysisResult, setAnalysisResult] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false); // Unified state for any ongoing processing
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);

  const handleDifficultyChange = (newDifficulty) => {
    setDifficulty(newDifficulty.charAt(0).toUpperCase() + newDifficulty.slice(1));
  };

  const startTest = async () => {
    setIsLoading(true);
    // Clear the previous state when starting a new test
    setQuestion('');
    setTranscription('');
    setAnalysisResult(null);

    const apiUrl = `https://aphid-game-ant.ngrok-free.app/generateques?difficulty=${encodeURIComponent(difficulty.toLowerCase())}`;
    try {
      const response = await fetch(apiUrl);
      if (response.ok) {
        const data = await response.json();
        setQuestion(data.question);
      } else {
        console.error("API call failed:", response.status);
      }
    } catch (error) {
      console.error("Error fetching question:", error);
    }
    setIsLoading(false);
  };

  const startRecording = async () => {
    if (isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    } else {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaRecorderRef.current = new MediaRecorder(stream);
        mediaRecorderRef.current.ondataavailable = (event) => {
          audioChunksRef.current.push(event.data);
        };
        mediaRecorderRef.current.onstop = async () => {
          setIsProcessing(true); // Indicate processing
          const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
          audioChunksRef.current = [];
          await sendAudioToServer(audioBlob);
          setIsProcessing(false); // Processing done
        };
        mediaRecorderRef.current.start();
        setIsRecording(true);
      } else {
        console.error("Audio recording is not supported by your browser.");
      }
    }
  };

  const sendAudioToServer = async (audioBlob) => {
    const formData = new FormData();
    formData.append('audio', audioBlob);
    try {
      const response = await fetch('https://aphid-game-ant.ngrok-free.app/transcribe', {
        method: 'POST',
        body: formData,
      });
      if (response.ok) {
        const data = await response.json();
        setTranscription(data.transcript);
        await analyzeAnswer(data.transcript);
      } else {
        console.error("Transcription API call failed:", response.status);
      }
    } catch (error) {
      console.error("Error sending audio to server:", error);
    }
  };

  const analyzeAnswer = async (transcript) => {
    setIsProcessing(true); // Indicate processing
    const apiUrl = `https://aphid-game-ant.ngrok-free.app/analyze?question=${encodeURIComponent(question)}&answer=${encodeURIComponent(transcript)}`;
    try {
      const response = await fetch(apiUrl);
      if (response.ok) {
        const contentType = response.headers.get('content-type');
        if (contentType && contentType.includes('application/json')) {
          const data = await response.json();
          setAnalysisResult(JSON.stringify(data, null, 2)); // Store the formatted JSON response
        } else {
          const data = await response.text();
          setAnalysisResult(data); // Store the response as text
        }
      } else {
        console.error("Analysis API call failed:", response.status);
      }
    } catch (error) {
      console.error("Error analyzing answer:", error);
    } // Processing done
  };

  return (
    <div className="test-container">
      <img src={logo} alt="WordWave Logo" className="logo" />
      <h1 className="animated-heading">Speaking Test</h1>

      {(isLoading || isProcessing) && (
        <div className="loading-container">
          <img src={loadingAnimation} alt="Loading..." className="loading-gif" />
        </div>
      )}

      {!isLoading && question && (
        <div className="question-container">
          <h2>Question:</h2>
          <p>{question}</p>
        </div>
      )}

      {!isProcessing && transcription && (
        <div className="transcription-container">
          <h2>Your Answer:</h2>
          <p>{transcription}</p>
        </div>
      )}

      {!isProcessing && analysisResult && (
        <div className="analysis-result-container" style={{ padding:'20px', marginLeft: '200px', marginRight: '200px' }}>
        <h2>Analysis Result: Grammar | Fluency | Explanation | Context </h2>
        <pre>{analysisResult}</pre>
      </div>
      
      )}

      <div className="controls-container">
        <div className="difficulty-selector">
          <button className="btn btn-secondary dropdown-toggle" type="button">
            {difficulty}
          </button>
          <ul className="dropdown-menu">
            <li><button className="dropdown-item" onClick={() => handleDifficultyChange('novice')}>Novice</button></li>
            <li><button className="dropdown-item" onClick={() => handleDifficultyChange('medium')}>Medium</button></li>
            <li><button className="dropdown-item" onClick={() => handleDifficultyChange('hard')}>Hard</button></li>
          </ul>
        </div>
        <button type="button" className="btn btn-primary" onClick={startTest} disabled={isLoading || isProcessing}>
          {isLoading ? 'Loading...' : 'Start Test'}
        </button>
        <button type="button" className="btn btn-info" onClick={startRecording} disabled={!isRecording && (isLoading || isProcessing)}>
          {isRecording ? 'Stop Recording' : 'Start Recording'}
        </button>
      </div>
    </div>
  );
};

export default SpeakingTest;
